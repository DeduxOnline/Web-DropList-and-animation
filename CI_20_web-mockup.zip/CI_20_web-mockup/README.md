CI_20_web lab1
Home page created
